RAILCORE FullDemo v1.2 — Offline, Audited, Single‑Source Routing
Built: 2025-11-11 09:42:08

Highlights:
- Source Registry + single-source routing (offline demo)
- Clickable Train ID modal on Ordered Trains (edit + save mirrors to lineup)
- Crew lineup corrected (one person per position, locked columns)
- Sticky headers in scrollable tables
- Data Audit panel with exportable report (JSON)
- Status enum normalization (PLN/ORD/DEP/DL/ARR)

Open in a full browser (Chrome/Edge/Safari). iOS Files Preview blocks JavaScript.