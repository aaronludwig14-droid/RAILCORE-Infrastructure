#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RAILCORE Infrastructure Builder (v1)
Merges raw NTAD rail line GeoJSON attributes (no geometry) and FRA crossing CSV
into a master file (CSV + JSON), and writes a separate geometry reference JSON.

Usage:
  pip install pandas geopandas openpyxl
  python build_railcore_master.py
"""
import json, csv, os, sys, datetime
from pathlib import Path

try:
    import pandas as pd
except Exception:
    print("Missing pandas. Please run: pip install pandas")
    sys.exit(1)

def load_geojson_attributes(path):
    path = Path(path)
    if not path.exists():
        return [], []
    with open(path, "r", encoding="utf-8") as f:
        gj = json.load(f)
    feats = gj.get("features", [])
    attr_rows, geom_rows = [], []
    ts = datetime.datetime.utcnow().isoformat()+"Z"
    for feat in feats:
        props = feat.get("properties", {}) or {}
        geom = feat.get("geometry")
        # Find a stable id if present
        feature_id = None
        for k in ["OBJECTID","ObjectID","FID","id","OBJECTID_1","FEATUREID","FRA_ID"]:
            if k in props:
                feature_id = props[k]
                break
        if feature_id is None:
            feature_id = abs(hash(json.dumps(props, sort_keys=True))) % (10**12)
        # Attributes (no geometry)
        row = dict(props)
        row["source_file"] = path.name
        row["merge_timestamp"] = ts
        attr_rows.append(row)
        # Geometry reference (separate file)
        if geom:
            geom_rows.append({
                "feature_id": feature_id,
                "railroad": props.get("RR") or props.get("RAILROAD") or props.get("Railroad"),
                "subdivision": props.get("SUBDIV") or props.get("Subdivision") or props.get("SUBDIVISION"),
                "geometry": geom.get("coordinates", None),
                "geometry_type": geom.get("type", None),
                "source_file": path.name
            })
    return attr_rows, geom_rows

def load_csv_with_source(path):
    path = Path(path)
    if not path.exists():
        return []
    import csv
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    ts = datetime.datetime.utcnow().isoformat()+"Z"
    for r in rows:
        r["source_file"] = path.name
        r["merge_timestamp"] = ts
    return rows

def write_csv(path, rows):
    if not rows:
        with open(path, "w", newline="", encoding="utf-8") as f:
            f.write("note\nno records written\n")
        return
    headers = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                headers.append(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        for r in rows:
            w.writerow(r)

def write_json(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)

def sort_rows(rows):
    def gl(d, ks):
        for k in ks:
            if k in d and d[k] is not None:
                return str(d[k]).lower()
        return "zzz"
    def gmp(d):
        for k in ["milepost","Milepost","MP","mp","MILEPOST"]:
            if k in d and d[k] not in (None, ""):
                try:
                    return float(str(d[k]).strip())
                except:
                    pass
        return float("inf")
    return sorted(rows, key=lambda r: (gl(r, ["railroad","Railroad","RR"]),
                                       gl(r, ["subdivision","Subdivision","SUBDIV","SUBDIVISION"]),
                                       gmp(r)))

def main():
    here = Path(__file__).resolve().parent
    src_geo1 = here / "NTAD_North_American_Rail_Network_Lines_Class_I_Railroads_1007084102822657698.json"
    src_geo2 = here / "NTAD_North_American_Rail_Network_Lines_Class_I_Railroads_-6957621637314786983.json"
    src_csv  = here / "NTAD_Railroad_Grade_Crossings_3132075552873265920.csv"

    all_attr, all_geom = [], []

    for p in [src_geo1, src_geo2]:
        a, g = load_geojson_attributes(p)
        all_attr.extend(a)
        all_geom.extend(g)

    all_attr.extend(load_csv_with_source(src_csv))

    all_attr = sort_rows(all_attr)

    out_csv = here / "railcore_master_infrastructure_raw.csv"
    out_json = here / "railcore_master_infrastructure_raw.json"
    out_geom = here / "railcore_geometry_reference.json"

    write_csv(out_csv, all_attr)
    write_json(out_json, all_attr)
    write_json(out_geom, all_geom)

    print("Done.")
    print("Wrote:", out_csv.name)
    print("Wrote:", out_json.name)
    print("Wrote:", out_geom.name)

if __name__ == "__main__":
    main()
