
RAILCORE Infrastructure Builder — Windows Quick Start (v1)
==========================================================

This package merges your Class I rail network attributes (no geometry) and FRA
grade crossings into a single RAW master dataset, and writes a separate geometry
reference JSON for Track Builder / map layers.

Outputs
-------
- railcore_master_infrastructure_raw.csv
- railcore_master_infrastructure_raw.json
- railcore_geometry_reference.json

Keep in Mind
------------
- ORIGINAL HEADERS are preserved exactly as in source files.
- Two new fields are added to every row: source_file, merge_timestamp.
- Sorting is by railroad → subdivision → milepost (if those fields exist).

Install (Windows)
-----------------
1) Install Python 3 (64-bit): https://www.python.org/downloads/
   • During install, check "Add python.exe to PATH"
2) Open Command Prompt in this folder and run:
   pip install pandas geopandas openpyxl

Run
---
• Double-click build_railcore_master.py
  -or-
• In Command Prompt:
  python build_railcore_master.py

After Run
---------
Files are written in this folder:
- railcore_master_infrastructure_raw.csv  ← fast filtering
- railcore_master_infrastructure_raw.json ← programmatic use
- railcore_geometry_reference.json        ← geometry keyed by feature_id

Notes
-----
- This is your append-only RAW data lake. Don't rename headers.
- Future datasets can be appended without breaking the raw master.
- Geometry is split to keep the master small and performant.

Generated: 2025-11-11T16:41:48.593832Z
